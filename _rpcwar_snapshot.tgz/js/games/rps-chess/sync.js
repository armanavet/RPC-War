/* ============================================================
   Online play for RPS Chess.

   All of the machinery — matches, Realtime, rematch, resign,
   abandon, ranked queue, chat — lives in js/net/matchsync.js and
   is shared with every other game. This file only says which game
   it is and how its end-reasons read.
   ============================================================ */
import {createSync} from '../../net/matchsync.js';
import {game, reset, move} from './state.js';
import * as ui from './ui.js';

const mp = createSync({
  slug: 'rps-chess',
  state: {game, reset, move},
  ui,
  reasons: {
    backrow: 'reached the back row',
  },
});

export const {
  mpCreate, mpJoin, mpLeave, mpRematch, mpResign, mpClaimAbandon,
  mpCopy, pushMove, mpFindMatch, mpLeaveQueue, sendChat, autoJoinFromHash,
} = mp;
